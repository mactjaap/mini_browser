<?php
header('Content-Type: text/html; charset=UTF-8');
header('Set-Cookie: mb_session=beta456; Path=/; Secure');
?>
<!doctype html>
<html><head><title>Phase 4 Cookie Replace</title></head><body>
<h1>COOKIE REPLACE PAGE</h1>
<p>Replaced mb_session with beta456</p>
<a href="phase4-cookie-check.php">Check replacement</a>
<p>END COOKIE REPLACE</p>
</body></html>
